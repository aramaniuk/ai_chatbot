class CustomClaudeSonnetModel:
    
    def build_prompt(self):
        pass 

    def generate(self):
        pass 