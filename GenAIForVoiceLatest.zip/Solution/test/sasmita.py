def foo():
    print("Sasmita is in class today")